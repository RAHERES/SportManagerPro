package com.example.sportmanagerpro.sportnutri.app;

import com.example.sportmanagerpro.sportnutri.ui.NuevoExpedienteView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) {
        NuevoExpedienteView view = new NuevoExpedienteView();

        Scene scene = new Scene(view, 1500, 900);

        URL css = com.example.sportmanagerpro.MainApp.class.getResource("nutrisport.css");
        if (css != null) {
            scene.getStylesheets().add(css.toExternalForm());
        }

        stage.setTitle("NutriSport Pro - Nuevo expediente");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}